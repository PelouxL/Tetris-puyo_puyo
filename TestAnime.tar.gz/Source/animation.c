#include <stdlib.h>
#include <stdio.h>
#include <MLV/MLV_all.h>
#include "types.h"


void afficher_animation( MLV_Animation_player *animation_player, int layer, int x, int y ){
  MLV_update_animation_player(animation_player);
  MLV_draw_image_from_animation_player(animation_player,layer, x, y);
}

MLV_Animation_player* creer_player( const char* chemin_image, int frame_w, int frame_h, int nb_frames ){
  MLV_Image * image;
  MLV_Image * frames[MAX_FRAMES];
  MLV_Animation *anim;
  MLV_Animation_player* animation_player;
  int i, j, x, y;
  
  if( (image = MLV_load_image(chemin_image) ) == NULL ){
    fprintf(stderr, "erreur lors du chargement de l'animation %s\n",chemin_image);
    return NULL;
  }
  
  for( i = 0 ; i < nb_frames ; i++ ){
    x = ( i % (MLV_get_image_width(image) / frame_w ) ) *frame_w;
    y = (i / (MLV_get_image_width(image) / frame_w)) * frame_h;
    
    frames[i] = MLV_copy_partial_image(image, x, y, frame_w, frame_h);
    if( frames[i] == NULL){
      fprintf(stderr, "Erreur a la frame %d\n",i);
      for( j = 0 ; j < i ; j++){
	MLV_free_image(frames[j]);
      }
      MLV_free_image(image);
      return NULL;
    }
  }

  anim = MLV_create_animation( nb_frames, 1, 1);
  /* on creer notre animation avec i representant chaque frame */
  for( i = 0 ; i < nb_frames ; i++ ){
    /* on ajoute notre images, pas de son, */
    if( MLV_add_frame_in_animation( &frames[i], NULL, 10, anim) == NULL){
      fprintf(stderr, "Erreur lors de l'ajout de la frame %d à l'animation\n", i);
      // Libérer les images et l'animation
      for( j = 0 ; j < nb_frames ; j++){
	MLV_free_image(frames[j]);
      }
      MLV_free_image(image);
      MLV_free_animation(anim);
      return NULL;

    }
  }

  /* creation du lecteur d'animation */
  animation_player = MLV_create_animation_player(anim);
  if( animation_player == NULL ){
    fprintf(stderr, "Erreur lors de la création du lecteur d'animation\n");
    // Libérer les ressources
    for( j = 0 ; j < nb_frames ; j++){
      MLV_free_image(frames[j]);
    }
    MLV_free_image(image);
    MLV_free_animation(anim);
    return NULL;
  }
  MLV_play_animation_player(animation_player);
  MLV_change_frame_rate(12);

  MLV_free_image(image);

  return animation_player;
}
