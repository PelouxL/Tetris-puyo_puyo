#ifndef _ANIMATION_H_
#define _ANIMATION_H_
#include "types.h"

void afficher_animation( MLV_Animation_player *anime_player, int x, int y );

MLV_Animation_player creer_player( const char* chemin_image,int layer, int frame_w, int frame_h, int nb_frames );


#endif
