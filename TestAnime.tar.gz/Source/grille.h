#ifndef GRILLE_H
#define GRILLE_H


/* affiche la grille de jeu sur le terminal */
void aff_grille(grille gr);

/* initialise le type "grille" */
grille initialisation_grille(int n, int m);

#endif
