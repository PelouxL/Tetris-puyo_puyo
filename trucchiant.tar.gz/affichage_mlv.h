#ifndef AFFICHAGE_MLV_H
#define AFFICHAGE_MLV_H

void aff_jeu();

void aff_etat(grille gr, joueur j);

#endif
