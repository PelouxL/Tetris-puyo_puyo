#ifndef _DESTRUCTION_H_
#define _DESTRUCTION_H_

void fusion_coord(coordonne *tcord1, coordonne *tcord2, int *taille1, int taille2);

int est_a_coter(poyo *p, grille *gr, coordonne *tcoord);

int recup_coord(poyo *p, grille *gr, coordonne *tcord);

void destruction(coordonne *tcord, grille *gr, int taille_t);

#endif
